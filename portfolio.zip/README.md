# Hi There, I'm Alireza :)


![Alireza Safari Github stats](https://github-readme-stats.vercel.app/api?username=alireza0sfr&show_icons=true)
